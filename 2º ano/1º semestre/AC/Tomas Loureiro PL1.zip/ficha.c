#include <stdio.h>

int my_atoi(char *str, int *tab);

int main(){
  char str[] = "453, 231, 128, 672";
  int tab[20], n, i;
  n = my_atoi(str, tab);
  printf("Tabela tab de inteiros:\n");
  for(i = 0; i<n; i++){
    printf("indice i=%d valor: %d", i, tab[i]);
  }
  printf("valor devolvido: %d\n", n);
  return 0;
}