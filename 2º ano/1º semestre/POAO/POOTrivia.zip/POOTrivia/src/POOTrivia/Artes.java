package POOTrivia;

import java.util.ArrayList;
import java.util.Collections;

public class Artes extends Pergunta {
	
	String resposta;

    public Artes() {
    }
    
    public Artes(String textoPergunta, ArrayList<String> opcoes, String resposta){
        super(textoPergunta, opcoes, resposta, "Artes");
    }

    public boolean verificar(String respostaUtilizador){
        return getResposta().equalsIgnoreCase(respostaUtilizador);
    }
    

}
