package POOTrivia;

public class RegistoJogo {

	public int pontos;
	public String dataHora, nomeJogador;
	
	public RegistoJogo(int pontos, String dataHora, String nomeJogador) {
		this.pontos = pontos;
		this.dataHora = dataHora;
		this.nomeJogador = nomeJogador;
	}
	
	public int getPontos() {
		return pontos;
	}
	
	public String getDataHora() {
		return dataHora;
	}
	
	public String getNomeJogador() {
		return nomeJogador;
	}
	
}
