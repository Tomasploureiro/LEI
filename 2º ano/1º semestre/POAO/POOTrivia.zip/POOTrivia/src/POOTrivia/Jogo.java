package POOTrivia;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class Jogo {
	
	 private int pontos;
	 private ArrayList<Pergunta> perguntas;
	 private ArrayList<Pergunta> perguntasRespondidas;
	 private ArrayList<Pergunta> perguntasCertas, perguntasErradas;
	 private int numeroPerguntasGeradas;
	 private int pontosPergunta;
	
	public Jogo() {
		perguntas = new ArrayList<>();
		perguntasRespondidas= new ArrayList<>();
		perguntasCertas = new ArrayList<>();
		perguntasErradas = new ArrayList<>();
		pontos = 0;
		numeroPerguntasGeradas = 0;
		pontosPergunta = 5;
	}
	

    public void carregarPerguntas(String ficheiro){
        try{
            Scanner sc = new Scanner(new File(ficheiro));
            
            while(sc.hasNextLine()){
                String tipoPergunta = sc.nextLine();
                Pergunta pergunta;
                if(tipoPergunta.equals("Artes")){
                    String textoPergunta = sc.nextLine();
                    ArrayList<String> opcoes = lerOpcoes(sc);
                    String resposta = sc.nextLine();
                    resposta = resposta.substring(9, resposta.length());
                    pergunta = new Artes(textoPergunta,opcoes,resposta);
                }else if(tipoPergunta.equals("Ciencias")){
                    String textoPergunta = sc.nextLine();
                    ArrayList<String> opcoesFaceis = lerOpcoes(sc);
                    ArrayList<String> opcoesDificeis = lerOpcoes(sc);
                    String resposta = sc.nextLine();
                    resposta = resposta.substring(9, resposta.length());
                    pergunta = new Ciencias(textoPergunta, opcoesFaceis, opcoesDificeis, resposta);
                }else if(tipoPergunta.equals("Futebol")){
                    String textoPergunta = sc.nextLine();
                    ArrayList<String> nomesJogadores = lerOpcoes(sc);
                    String respostaNomes = sc.nextLine();
                    respostaNomes = respostaNomes.substring(9, respostaNomes.length());
                    ArrayList<String> numerosJogadores = lerOpcoes(sc);
                    String respostaNumeros = sc.nextLine();
                    respostaNumeros = respostaNumeros.substring(9, respostaNumeros.length());
                    pergunta = new Futebol(textoPergunta, nomesJogadores, numerosJogadores, respostaNomes, respostaNumeros,tipoPergunta);
                }else if(tipoPergunta.equals("Natacao")){
                    String textoPergunta = sc.nextLine();
                    ArrayList<String> opcoes = lerOpcoes(sc);
                    String resposta = sc.nextLine();
                    resposta = resposta.substring(9, resposta.length());
                    pergunta = new Natacao(textoPergunta, opcoes, resposta, tipoPergunta);
                }else if(tipoPergunta.equals("Ski")){
                    String textoPergunta = sc.nextLine();
                    ArrayList<String> opcoes = lerOpcoes(sc);
                    String resposta = sc.nextLine();
                    resposta = resposta.substring(9, resposta.length());
                    pergunta = new Ski(textoPergunta, opcoes, resposta, tipoPergunta);                    
                }else {
                    pergunta = null;
                }
                sc.nextLine();
                if(pergunta != null){
                    perguntas.add(pergunta);
                }
        }
        sc.close();
        }catch(FileNotFoundException e){
            e.printStackTrace();
        }
    }

    public ArrayList<String> lerOpcoes(Scanner sc){
        ArrayList<String> opcoes = new ArrayList<>();
        String numOpcoesString = sc.nextLine();
        int numOpcoes = Integer.parseInt(numOpcoesString);

        for(int i = 0; i<numOpcoes; i++){
            opcoes.add(sc.nextLine());
        }

        return opcoes;
    }
    
    public ArrayList<Pergunta> obterPerguntasObjecto() {
    	return perguntas;
    }

    public void imprimirPerguntas(){
        for (Pergunta p :perguntas){
            System.out.println(p.toString());
        }
    }   

    public Pergunta escolherPerguntaAleatoria(){
        Random random = new Random();
        int indice = random.nextInt(perguntas.size());
                
        Pergunta perguntaAux = perguntas.get(indice);
        
        boolean encontrarPergunta = false;
        
        while(!encontrarPergunta) {
        	if (perguntasRespondidas.contains(perguntaAux)) {
        		indice = random.nextInt(perguntas.size());
            	perguntaAux = perguntas.get(indice);
            }
        	else {
        		encontrarPergunta = true;
        	}
        }
        
        numeroPerguntasGeradas++;
        

		return perguntaAux;
       
    }
    
    public int obterPontos() {
    	return pontos;
    }
    
    public boolean verificarResposta(Pergunta pergunta, String respostaSelecionada) {
    	perguntasRespondidas.add(pergunta);
    	
    	boolean correto = pergunta.verificar(respostaSelecionada, numeroPerguntasGeradas);
    	
    	if(correto) {
    		
    		perguntasCertas.add(pergunta);
    		
    		if(pergunta.getTipoPergunta().equals("Artes")) {
    			pontos= pontos + (pontosPergunta * 10);
    		}
    		else if(pergunta.getTipoPergunta().equals("Ciencias")) {
    			pontos= pontos + (pontosPergunta + 5);
    		}
    		else if(pergunta.getTipoPergunta().equals("Futebol")) {
				pontos= pontos + (pontosPergunta + 1 + 3);
			}
			else if(pergunta.getTipoPergunta().equals("Natacao")) {
				pontos= pontos + (pontosPergunta + 10 + 3);
			}
			else if(pergunta.getTipoPergunta().equals("Ski")) {
				pontos= pontos + ((pontosPergunta + 3) * 2);
			}
    		
    	}
    	else {
    		perguntasErradas.add(pergunta);
    	}
    	
		return correto;
    	
    }
    
    public ArrayList<String> getOp��esPergunta(Pergunta pergunta){
    	return pergunta.getOpcoes(numeroPerguntasGeradas);
    }
    
    public int obterNumeroPerguntasGeradas() {
    	return numeroPerguntasGeradas;
    }
    
    public void acabarJogo(String nomeJogador){
    	DateTimeFormatter formatterToFile = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    	DateTimeFormatter formatterToName = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
    	
    	String dataHoraAtualNome = LocalDateTime.now().format(formatterToName);
    	String datahoraAtualFicheiro = LocalDateTime.now().format(formatterToFile);
    	
    	String nomeArquivo = "Jogos\\pootrivia_jogo_" + dataHoraAtualNome + "_" +obterIniciaisNome(nomeJogador) + ".dat";
    	
    	
    	File arquivo = new File(nomeArquivo);
    	
    	try {
    		FileWriter fileWriter = new FileWriter(arquivo);
    		
    		String textoParaGravar = "Data e hora: " + datahoraAtualFicheiro + "\nNome do jogador: " + nomeJogador +
                    "\nPontuacao: " + pontos;
    		
    		fileWriter.write(textoParaGravar);
    		fileWriter.close();
    		
    	} catch (IOException e) {
            e.printStackTrace();
        }
    	    	
    }
    
    
    private static String obterIniciaisNome(String nomeCompleto) {
        StringBuilder iniciais = new StringBuilder();

        String[] palavras = nomeCompleto.split("\\s+");

        for (String palavra : palavras) {
            if (!palavra.isEmpty()) {
                iniciais.append(palavra.charAt(0));
            }
        }

        return iniciais.toString();
    }
}
