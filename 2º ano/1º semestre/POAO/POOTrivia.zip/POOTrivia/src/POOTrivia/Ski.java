package POOTrivia;

import java.util.ArrayList;

public class Ski extends Desporto{
    
    public Ski(){
    }

    public Ski(String textoPergunta, ArrayList<String> opcoes, String resposta, String tipoPergunta){
        super(textoPergunta, opcoes, resposta,tipoPergunta);
    }
    
    
}
