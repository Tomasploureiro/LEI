package POOTrivia;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

@SuppressWarnings("serial")
public class POOTrivia extends JFrame {
	
	private Jogo jogo;
    private JButton botaoEscolherPergunta;
    private JButton botaoProximaPergunta;
    private JLabel labelPergunta;
    private JPanel panelOpcoes;
    private JLabel labelPontuacao;
    
    private boolean primeiraEscolha = true;
    private boolean escolheuOpcao = false;

    private Pergunta perguntaAtual;
    
    private List<RegistoJogo> registros;
    
    public POOTrivia () {
    	setTitle("POOTrivia");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JPanel painel = new JPanel();
        
      
        botaoEscolherPergunta = new JButton("Come�ar Jogo");
        botaoEscolherPergunta.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	jogo = new Jogo();
                jogo.carregarPerguntas("C:\\Users\\Pedro Maia\\eclipse-workspace\\POOTrivia\\perguntas.txt");
                
                exibirPerguntaAleatoria();
            }
        });

        painel.add(botaoEscolherPergunta);
        getContentPane().add(painel);

        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    private void exibirPerguntaAleatoria() {
        if (primeiraEscolha) {
        	getContentPane().removeAll();
            revalidate();
            repaint();
            primeiraEscolha = false;
        }

        if(jogo.obterNumeroPerguntasGeradas() < 5) {
        	perguntaAtual = jogo.escolherPerguntaAleatoria();

            labelPergunta = new JLabel();
            labelPergunta.setHorizontalAlignment(SwingConstants.CENTER);
            labelPergunta.setText(perguntaAtual.getTextoPergunta());
            Font fonte = labelPergunta.getFont();
            labelPergunta.setFont(new Font(fonte.getName(), Font.PLAIN, 20));

            panelOpcoes = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.insets = new Insets(5, 5, 5, 5);

            ArrayList<String> opcoes = jogo.getOp��esPergunta(perguntaAtual);
            
            for (int i = 0; i < opcoes.size(); i++) {
                JButton botaoOpcao = new JButton();
                botaoOpcao.setText((i + 1) + ") " + opcoes.get(i));
                botaoOpcao.addActionListener(new OpcaoActionListener(i, perguntaAtual.getResposta(), botaoOpcao));
                gbc.gridy = i;
                panelOpcoes.add(botaoOpcao, gbc);
            }

            botaoProximaPergunta = new JButton("Pr�xima Pergunta");
            botaoProximaPergunta.setEnabled(false);
            botaoProximaPergunta.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    removerPerguntaAtual();
                    exibirPerguntaAleatoria();
                }
            });

            labelPontuacao = new JLabel("Pontua��o: " + jogo.obterPontos());

            JPanel panelPrincipal = new JPanel(new GridBagLayout());
            gbc.gridx = 0;
            gbc.gridy = 0;
            panelPrincipal.add(labelPergunta, gbc);

            gbc.gridy = 1;
            panelPrincipal.add(panelOpcoes, gbc);

            gbc.gridy = 2;
            panelPrincipal.add(botaoProximaPergunta, gbc);

            gbc.gridx = 1;
            gbc.gridy = 0;
            gbc.gridheight = 3;
            panelPrincipal.add(labelPontuacao, gbc);

            getContentPane().add(panelPrincipal);

            revalidate();
            repaint();
        }
        else {
        	 getContentPane().removeAll();
        	 
        	 setLayout(new BorderLayout());
        	 
        	 JLabel labelFimJogo = new JLabel("Fim do Jogo! Pontua��o final: " + jogo.obterPontos());
        	 labelFimJogo.setHorizontalAlignment(SwingConstants.CENTER);
        	 getContentPane().add(labelFimJogo, BorderLayout.NORTH);
        	 
        	 JPanel centerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        	 JTextField textFieldNome = new JTextField("Digite seu nome", 15);
             centerPanel.add(textFieldNome);
             getContentPane().add(centerPanel, BorderLayout.CENTER);
             
             JButton buttonSubmit = new JButton("Submit");
             buttonSubmit.addActionListener(new ActionListener() {
                 @Override
                 public void actionPerformed(ActionEvent e) {
                     String nomeJogador = textFieldNome.getText();
                     System.out.println("Nome do jogador: " + nomeJogador);
                     jogo.acabarJogo(nomeJogador);
                     System.out.println("Nome do jogador depois: " + nomeJogador);
                     leaderBoard();
                 }
             });
             getContentPane().add(buttonSubmit, BorderLayout.SOUTH);

             revalidate();
             repaint();
        }
        
    }
    
    
    
    private void removerPerguntaAtual() {
        getContentPane().removeAll();           
        revalidate();
        repaint();
        escolheuOpcao = false;
    }
    
    private void leaderBoard() {
    	
    	String pastaPath = "Jogos";
    	
    	File pasta = new File(pastaPath);
        File[] arquivos = pasta.listFiles();
        
        registros = new ArrayList<>();
        
        if (arquivos != null) {
        	for (File arquivo : arquivos) {
        		List<String> linhas = new ArrayList<>();
        		try (BufferedReader reader = new BufferedReader(new FileReader(arquivo))) {
                    String linha;
                    while ((linha = reader.readLine()) != null) {
                        linhas.add(linha);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
        		
        		int pontos = 0;
        		String dataHora = null, nomeJogador = null;
        		
        		for (String linha : linhas) {
        			if (linha.startsWith("Data e hora:")) {
        				dataHora = linha.substring("Data e hora: ".length());
        			}
        			else if (linha.startsWith("Nome do jogador:")) {
        				nomeJogador = linha.substring("Nome do jogador: ".length());
        			}
        			else if (linha.startsWith("Pontuacao:")) {
        				pontos = Integer.parseInt(linha.substring("Pontuacao: ".length()));
        			}
        		}
        		
        		registros.add(new RegistoJogo(pontos, dataHora, nomeJogador));
        	}
        }
        

        Collections.sort(registros, (r1, r2) -> {
            int pointsComparison = Integer.compare(r2.getPontos(), r1.getPontos());
            if (pointsComparison != 0) {
                return pointsComparison;
            }

            return r1.getDataHora().compareTo(r2.getDataHora());
        });
            
            	
    	getContentPane().removeAll();
    	
    	setLayout(new GridLayout(registros.size() + 1, 1));
        JLabel headerLabel = new JLabel("Leaderboard");
        headerLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(headerLabel);
        
        int leaderSize = registros.size();
        if(leaderSize > 3) {
        	leaderSize = 3;
        }
        
        for (int i = 0; i < leaderSize; i++) {
        	RegistoJogo registo = registros.get(i);
            JLabel entryLabel = new JLabel("Nome Jogador: " + registo.getNomeJogador() +
                    "       Pontos: " + registo.getPontos() +
                    "       DataHora: " + registo.getDataHora());
            entryLabel.setHorizontalAlignment(SwingConstants.CENTER);
            add(entryLabel);
        }
        
        JButton returnButton = new JButton("Comecar novo jogo");
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	getContentPane().removeAll();
            	
                jogo = new Jogo();
                jogo.carregarPerguntas("C:\\Users\\Pedro Maia\\eclipse-workspace\\POOTrivia\\perguntas.txt");
                primeiraEscolha = true;
                setLayout(new GridBagLayout());
                revalidate();
                repaint();
                exibirPerguntaAleatoria();
            }
        });
        add(returnButton);
    	
        revalidate();
        repaint();
    }
    
    private class OpcaoActionListener implements ActionListener {
        private int opcaoIndex;
        private String respostaCorreta;
        private JButton botaoOpcao;

        public OpcaoActionListener(int index, String respostaCorreta, JButton botaoOpcao) {
            this.opcaoIndex = index;
            this.respostaCorreta = respostaCorreta;
            this.botaoOpcao = botaoOpcao;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (!escolheuOpcao) {
            	System.out.println(jogo.getOp��esPergunta(perguntaAtual).get(opcaoIndex));
                if (jogo.verificarResposta(perguntaAtual, jogo.getOp��esPergunta(perguntaAtual).get(opcaoIndex))) {
                    botaoOpcao.setBackground(Color.GREEN);
                } else {
                    botaoOpcao.setBackground(Color.RED);
                }

                for (Component component : panelOpcoes.getComponents()) {
                    if (component instanceof JButton) {
                        JButton button = (JButton) component;
                        button.setEnabled(false);
                    }
                }

                botaoProximaPergunta.setEnabled(true);
                escolheuOpcao = true;
            }

            labelPontuacao.setText("Pontua��o: " + jogo.obterPontos());
        }	
    }

	

	public static void main(String[] args) {
		POOTrivia pootrivia = new POOTrivia();

	}

}
