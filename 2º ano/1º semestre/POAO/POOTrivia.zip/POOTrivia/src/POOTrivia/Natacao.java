package POOTrivia;

import java.util.ArrayList;

public class Natacao extends Desporto {
    
    public Natacao(){
    }

    public Natacao(String textoPergunta, ArrayList<String> opcoes, String resposta, String tipoPergunta){
        super(textoPergunta, opcoes, resposta, tipoPergunta);
    }
    
}
