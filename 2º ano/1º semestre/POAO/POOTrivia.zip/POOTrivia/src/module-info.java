module POOTrivia {
	requires java.desktop;
}