#pragma once
#include "ofMain.h"
#include <deque>

struct Point {
    int x, y;
};

enum CameraMode { ORTHO, PERSPECTIVE, FIRST_PERSON };
enum GameState { MENU, PLAYING };

class ofApp : public ofBaseApp {
public:
    void setup();
    void update();
    void draw();

    void keyPressed(int key);

    void initializeGame();
    void spawnFood();
    void updateGame();
    void drawPlatform();
    void drawRectangle(int x, int y, float r, float g, float b);

    std::deque<Point> snake;
    Point food;
    int direction;
    int score;
    int highScore;
    std::string highScoreFile = "highscore.txt";

    GameState gameState;
    std::vector<std::string> menuOptions;
    int selectedOption;

    CameraMode cameraMode;
    ofCamera camera;
    float cameraAngle;

    const int GRID_SIZE = 20;
    const int GRID_COUNT = 40;

    float lastUpdateTime;
    float updateInterval;

    int glowFrames;
    bool glowing;

    int reduceIndex;
    bool reducing;

    float resetTimer;
    bool resetting;

};
