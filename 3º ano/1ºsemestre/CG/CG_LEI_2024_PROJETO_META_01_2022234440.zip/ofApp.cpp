#include "ofApp.h"

void ofApp::setup() {
    ofSetFrameRate(60);
    initializeGame();

    cameraMode = ORTHO;
    camera.setFov(45);
    camera.setPosition(0, 0, GRID_COUNT * GRID_SIZE * 1.5);
    camera.lookAt(glm::vec3(0, 0, 0));

    gameState = MENU;
    menuOptions = { "Start Game", "Exit" };
    selectedOption = 0;

    lastUpdateTime = ofGetElapsedTimef();
    updateInterval = 0.1f;

    std::ifstream inputFile(highScoreFile);
    if (inputFile.is_open()) {
        inputFile >> highScore;
        inputFile.close();
    }
    else {
        highScore = 0;
    }
}


void ofApp::initializeGame() {
    snake.clear();
    snake.push_back({ GRID_COUNT / 2, GRID_COUNT / 2 });
    spawnFood();
    direction = 0;
    score = 0;
    glowFrames = 0;
    glowing = false;
    reduceIndex = -1;
    reducing = false;
    resetting = false;
    resetTimer = 0.0f;
    cameraAngle = 0.0f;

}



void ofApp::spawnFood() {
    bool positionValid = false;

    while (!positionValid) {
        food.x = rand() % GRID_COUNT;
        food.y = rand() % GRID_COUNT;

        positionValid = true;
        for (const Point& segment : snake) {
            if (segment.x == food.x && segment.y == food.y) {
                positionValid = false;
                break;
            }
        }
    }
}


void ofApp::keyPressed(int key) {
    if (gameState == MENU) {
        if (key == 'w') {
            selectedOption = (selectedOption - 1 + menuOptions.size()) % menuOptions.size();
        }
        else if (key == 's') {
            selectedOption = (selectedOption + 1) % menuOptions.size();
        }
        else if (key == OF_KEY_RETURN) {
            if (selectedOption == 0) {
                gameState = PLAYING;
                initializeGame();
            }
            else if (selectedOption == 1) {
                std::exit(0);
            }
        }
        return;
    }

    if (gameState == PLAYING) {
        if (key == '1') cameraMode = ORTHO;
        if (key == '2') cameraMode = PERSPECTIVE;
        if (key == '3') cameraMode = FIRST_PERSON;

        if (cameraMode == PERSPECTIVE) {
            if (key == 'w' && direction != 0) direction = 2;
            if (key == 'd' && direction != 3) direction = 1;
            if (key == 's' && direction != 2) direction = 0;
            if (key == 'a' && direction != 1) direction = 3;
        }
        else if (cameraMode == FIRST_PERSON) {
            if (key == 'a') {
                cameraAngle -= 90.0f;
                direction = (direction + 1) % 4;
            }
            if (key == 'd') {
                cameraAngle += 90.0f;
                direction = (direction + 3) % 4;
            }
        }
        else {
            if (key == 'w' && direction != 2) direction = 0;
            if (key == 'd' && direction != 3) direction = 1;
            if (key == 's' && direction != 0) direction = 2;
            if (key == 'a' && direction != 1) direction = 3;
        }
    }
}


void ofApp::update() {
    float currentTime = ofGetElapsedTimef();
    if (currentTime - lastUpdateTime >= updateInterval) {
        updateGame();
        lastUpdateTime = currentTime;
    }
}

void ofApp::updateGame() {
    if (resetting) {
        if (ofGetElapsedTimef() >= resetTimer) {
            gameState = MENU;
        }
        return;
    }

    if (reducing) {
        if (!snake.empty() && reduceIndex < snake.size() - 1) {
            snake.pop_back();
        }
        else {
            resetting = true;
            resetTimer = ofGetElapsedTimef() + 1.0f;
        }
        return;
    }

    Point head = snake.front();

    switch (direction) {
    case 0: head.y -= 1; break;
    case 1: head.x += 1; break;
    case 2: head.y += 1; break;
    case 3: head.x -= 1; break;
    }

    if (head.x < 0 || head.y < 0 || head.x >= GRID_COUNT || head.y >= GRID_COUNT) {
        reducing = true;
        reduceIndex = 0;
        return;
    }

    for (size_t i = 1; i < snake.size(); ++i) {
        if (snake[i].x == head.x && snake[i].y == head.y) {
            reducing = true;
            reduceIndex = 0;
            return;
        }
    }

    if (head.x == food.x && head.y == food.y) {
        snake.push_front(head);
        spawnFood();
        score += 10;

        if (score > highScore) {
            highScore = score;
            std::ofstream outputFile(highScoreFile);
            if (outputFile.is_open()) {
                outputFile << highScore;
                outputFile.close();
            }
        }
        glowing = true;
        glowFrames = 50;
    }
    else {
        snake.push_front(head);
        snake.pop_back();
    }
}




void ofApp::drawPlatform() {
    float platformSize = GRID_COUNT * GRID_SIZE;
    float platformThickness = GRID_SIZE / 10.0f;
    float platformCenter = GRID_COUNT * GRID_SIZE / 2.0f;
    ofSetColor(192, 192, 192);
    if (cameraMode == ORTHO) {
        float boardX = (ofGetWidth() - platformSize) / 2.0f;
        float boardY = (ofGetHeight() - platformSize) / 2.0f;
        ofDrawRectangle(boardX, boardY, platformSize, platformSize);
    }
    else if (cameraMode == PERSPECTIVE || cameraMode == FIRST_PERSON) {
        ofDrawBox(platformCenter, platformCenter, -platformThickness / 2.0f, platformSize, platformSize, platformThickness);
    }
}



void ofApp::draw() {
    if (gameState == MENU) {
        ofBackground(30, 30, 30);

        ofSetColor(255, 255, 255);
        ofDrawBitmapString("SNAKE GAME", ofGetWidth() / 2 - 50, ofGetHeight() / 3);

        for (size_t i = 0; i < menuOptions.size(); i++) {
            if (i == selectedOption) {
                ofSetColor(0, 255, 0);
            }
            else {
                ofSetColor(255, 255, 255);
            }
            ofDrawBitmapString(menuOptions[i], ofGetWidth() / 2 - 40, ofGetHeight() / 2 + i * 30);
        }

        ofSetColor(150, 150, 150);
        ofDrawBitmapString("Use 'W' and 'S' to navigate", ofGetWidth() / 2 - 100, ofGetHeight() / 2 + 100);
        ofDrawBitmapString("Press 'Enter' to select", ofGetWidth() / 2 - 100, ofGetHeight() / 2 + 120);

        ofDrawBitmapString("How to Play:", ofGetWidth() / 2 - 100, ofGetHeight() / 2 + 160);
        ofDrawBitmapString("- 'W', 'A', 'S', 'D' to move the snake", ofGetWidth() / 2 - 100, ofGetHeight() / 2 + 180);
        ofDrawBitmapString("- 'A', 'D' to move the snake in third person mode", ofGetWidth() / 2 - 100, ofGetHeight() / 2 + 200);
        ofDrawBitmapString("- '1', '2', '3' to alternate between camera modes", ofGetWidth() / 2 - 100, ofGetHeight() / 2 + 220);
        ofDrawBitmapString("- Avoid the edges and yourself", ofGetWidth() / 2 - 100, ofGetHeight() / 2 + 240);
        ofDrawBitmapString("- Eat the food to grow and score points", ofGetWidth() / 2 - 100, ofGetHeight() / 2 + 260);

        return;
    }

    if(gameState == PLAYING){
        ofBackground(51, 51, 51);
        if (cameraMode == ORTHO) {
            ofPushMatrix();
            ofSetupScreenOrtho();
            drawPlatform();
            float center = (ofGetWidth() - GRID_COUNT * GRID_SIZE) / 2.0f;
            float height = (ofGetHeight() - GRID_COUNT * GRID_SIZE) / 2.0f;
            ofPushMatrix();
            ofTranslate(center, height);
            for (size_t i = 0; i < snake.size(); ++i) {
                drawRectangle(snake[i].x, snake[i].y, 0.0f, 1.0f, 0.0f);
            }
            drawRectangle(food.x, food.y, 1.0f, 0.0f, 0.0f);
            ofPopMatrix();
            ofPopMatrix();
        } else {
            camera.begin();

            if (cameraMode == PERSPECTIVE) {
                float center = GRID_COUNT * GRID_SIZE / 2.0f;
                float height = GRID_COUNT * GRID_SIZE * 1.5f;

                camera.setPosition(center, -center * 2, height);
                camera.lookAt(glm::vec3(center, center, 0));
                camera.begin();

                drawPlatform();

                for (size_t i = 0; i < snake.size(); ++i) {
                    drawRectangle(snake[i].x, snake[i].y, 0.0f, 1.0f, 0.0f);
                }
                drawRectangle(food.x, food.y, 1.0f, 0.0f, 0.0f);

                camera.end();
            } else if (cameraMode == FIRST_PERSON) {
                Point head = snake.front();

                float cameraX = head.x * GRID_SIZE + GRID_SIZE / 2.0f;
                float cameraY = head.y * GRID_SIZE + GRID_SIZE / 2.0f;
                float cameraZ = GRID_SIZE;

                glm::vec3 lookAtPosition;
                switch (direction) {
                case 0:
                    lookAtPosition = glm::vec3(cameraX, cameraY - GRID_SIZE, cameraZ);
                    break;
                case 1:
                    lookAtPosition = glm::vec3(cameraX + GRID_SIZE, cameraY, cameraZ);
                    break;
                case 2:
                    lookAtPosition = glm::vec3(cameraX, cameraY + GRID_SIZE, cameraZ);
                    break;
                case 3:
                    lookAtPosition = glm::vec3(cameraX - GRID_SIZE, cameraY, cameraZ);
                    break;
                }

                camera.setPosition(cameraX, cameraY, cameraZ);
                camera.lookAt(lookAtPosition, glm::vec3(0, 0, 1));

                camera.begin();

                drawPlatform();

                for (size_t i = 0; i < snake.size(); ++i) {
                    drawRectangle(snake[i].x, snake[i].y, 0.0f, 1.0f, 0.0f);
                }

                drawRectangle(food.x, food.y, 1.0f, 0.0f, 0.0f);

                camera.end();
            }

            camera.end();
        }


        if (resetting) {
            ofPushMatrix();
            ofSetupScreenOrtho();
            ofSetColor(255, 0, 0);
            ofDrawBitmapString("Game Over | Score: " + std::to_string(score), ofGetWidth() / static_cast<float>(2) - 80, ofGetHeight() / static_cast<float>(2)); //8px por letra (8x20) / 2
            ofPopMatrix();
        }

        ofPushMatrix();
        ofSetupScreenOrtho();
        ofSetColor(255, 255, 255);
        ofDrawBitmapString("High Score: " + std::to_string(highScore), 10, 20);
        ofDrawBitmapString("Score: " + std::to_string(score), 10, 40);
        ofPopMatrix();
    }
}





void ofApp::drawRectangle(int x, int y, float r, float g, float b) {
    float cellSize = GRID_SIZE;

    float xpos = x * cellSize + cellSize / 2.0f;
    float ypos = y * cellSize + cellSize / 2.0f;

    ofSetColor(r * 255, g * 255, b * 255);

    if (glowing && glowFrames > 0) {
        ofSetColor(255, 255, 0);
        glowFrames--;
        if (glowFrames == 0) glowing = false;
    }

    if (cameraMode == ORTHO) {
        ofDrawRectangle(x * cellSize, y * cellSize, cellSize, cellSize);
    }
    else if (cameraMode == PERSPECTIVE || cameraMode == FIRST_PERSON) {
        ofDrawBox(xpos, ypos, 0, cellSize, cellSize, cellSize);
    }
}





