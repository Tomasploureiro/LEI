#include "ofApp.h"

GLfloat noLight[] = { 0.0f, 0.0f, 0.0f, 1.0f };


GLfloat dirLightPosition[] = { 0.0, 0.0, -1.0, 0.0 };
GLfloat dirLightAmbient[] = { 2.0, 2.0, 2.0, 1.0 };
GLfloat dirLightDiffuse[] = { 1.0, 1.0, 1.0, 1.0 };
GLfloat dirLightSpecular[] = { 0.5, 0.5, 0.5, 1.0 };
bool dirLightEnabled = true;

GLfloat spotLightAmbient[] = { 5.0f, 5.0f, 5.0f, 1.0f };
GLfloat spotLightDiffuse[] = { 3.0f, 3.0f, 3.0f, 1.0f };
GLfloat spotLightSpecular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
GLfloat spotExponent = 20.0f;
GLfloat spotCutoff = 60.0f;
bool spotLightEnabled = true;

GLfloat pointLightAmbient[] = { 5.0f, 5.0f, 5.0f, 1.0f };
GLfloat pointLightDiffuse[] = { 2.0f, 2.0f, 2.0f, 1.0f };
GLfloat pointLightSpecular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
bool pointLightEnabled = true;

bool dirLightAmbientEnabled = true;
bool dirLightDiffuseEnabled = true;
bool dirLightSpecularEnabled = true;

bool spotLightAmbientEnabled = true;
bool spotLightDiffuseEnabled = true;
bool spotLightSpecularEnabled = true;

bool pointLightAmbientEnabled = true;
bool pointLightDiffuseEnabled = true;
bool pointLightSpecularEnabled = true;

void ofApp::setup() {
    ofSetFrameRate(60);
    initializeGame();

    cameraMode = ORTHO;
    camera.setFov(45);
    camera.setPosition(0, 0, GRID_COUNT * GRID_SIZE * 1.5);
    camera.lookAt(glm::vec3(0, 0, 0));

    gameState = MENU;
    menuOptions = { "Start Game", "Difficulty: Easy", "Exit" };
    selectedOption = 0;

    lastUpdateTime = ofGetElapsedTimef();
    updateInterval = 0.1f;

    std::ifstream inputFile(highScoreFile);
    if (inputFile.is_open()) {
        inputFile >> highScore;
        inputFile.close();
    }
    else {
        highScore = 0;
    }

    ofDisableArbTex();

    img1.load("texture1.png");
    img2.load("texture2.png");
    img3.load("texture3.png");
    img4.load("texture4.png");
 
    float z = gh() * 0.25 * (cos(dirVecTheta * PI / 180.) * 0.5 + 0.45);
    float y = gh() * 0.5;
    float x = 0;
    dirVec3f = ofVec3f(x, y, z) - ofVec3f(0, 0, 0);

    glEnable(GL_LIGHTING);

    glLightfv(GL_LIGHT0, GL_POSITION, dirLightPosition);
    glLightfv(GL_LIGHT0, GL_AMBIENT, dirLightAmbient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, dirLightDiffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, dirLightSpecular);
    glEnable(GL_LIGHT0);

    glLightfv(GL_LIGHT2, GL_AMBIENT, spotLightAmbient);
    glLightfv(GL_LIGHT2, GL_DIFFUSE, spotLightDiffuse);
    glLightfv(GL_LIGHT2, GL_SPECULAR, spotLightSpecular);
    glLightf(GL_LIGHT2, GL_SPOT_EXPONENT, spotExponent);
    glLightf(GL_LIGHT2, GL_SPOT_CUTOFF, spotCutoff);
    glEnable(GL_LIGHT2);

    glLightfv(GL_LIGHT1, GL_AMBIENT, pointLightAmbient);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, pointLightDiffuse);
    glLightfv(GL_LIGHT1, GL_SPECULAR, pointLightSpecular);

    glLightf(GL_LIGHT1, GL_CONSTANT_ATTENUATION, 1.0f);
    glLightf(GL_LIGHT1, GL_LINEAR_ATTENUATION, 0.01f);
    glLightf(GL_LIGHT1, GL_QUADRATIC_ATTENUATION, 0.001f);

    glEnable(GL_LIGHT1);

}


void ofApp::initializeGame() {
    snake.clear();
    snake.push_back({ GRID_COUNT / 2, GRID_COUNT / 2 });
    spawnFood();
    direction = 0;
    score = 0;
    glowFrames = 0;
    glowing = false;
    reduceIndex = -1;
    reducing = false;
    resetting = false;
    resetTimer = 0.0f;
    cameraAngle = 0.0f;

    updateInterval = (modoDificuldade == EASY) ? easyUpdateInterval : hardUpdateInterval;

}


void ofApp::spawnFood() {
    bool positionValid = false;

    while (!positionValid) {
        food.x = rand() % GRID_COUNT;
        food.y = rand() % GRID_COUNT;

        positionValid = true;
        for (const Point& segment : snake) {
            if (segment.x == food.x && segment.y == food.y) {
                positionValid = false;
                break;
            }
        }
    }
}


void ofApp::keyPressed(int key) {
    if (gameState == MENU) {
        if (key == 'w') {
            selectedOption = (selectedOption - 1 + menuOptions.size()) % menuOptions.size();
        }
        else if (key == 's') {
            selectedOption = (selectedOption + 1) % menuOptions.size();
        }
        else if (key == OF_KEY_RETURN) {
            if (selectedOption == 0) {
                gameState = PLAYING;
                initializeGame();
            }
            else if (selectedOption == 1) {
                modoDificuldade = (modoDificuldade == EASY) ? HARD : EASY;
                updateInterval = (modoDificuldade == EASY) ? easyUpdateInterval : hardUpdateInterval;
                menuOptions[1] = "Difficulty: " + std::string((modoDificuldade == EASY) ? "Easy" : "Hard");
            }
            else if (selectedOption == 2) {
                std::exit(0);
            }
        }
        return;
    }

    if (gameState == PLAYING) {

        if (key == 'z')  dirLightAmbientEnabled = !dirLightAmbientEnabled;
        if (key == 'x')  dirLightDiffuseEnabled = !dirLightDiffuseEnabled;
        if (key == 'c')  dirLightSpecularEnabled = !dirLightSpecularEnabled;

            // Foco
        if (key == 'v')  spotLightAmbientEnabled = !spotLightAmbientEnabled;
        if (key == 'b')  spotLightDiffuseEnabled = !spotLightDiffuseEnabled;
        if (key == 'n')  spotLightSpecularEnabled = !spotLightSpecularEnabled;

            // Pontual
        if (key == 'm')  pointLightAmbientEnabled = !pointLightAmbientEnabled;
        if (key == ',')  pointLightDiffuseEnabled = !pointLightDiffuseEnabled;
        if (key == '.')  pointLightSpecularEnabled = !pointLightSpecularEnabled;

        if (key == '1') cameraMode = ORTHO;
        if (key == '2') cameraMode = PERSPECTIVE;
        if (key == '3') cameraMode = FIRST_PERSON;
        if (key == '4') {
            dirLightEnabled = !dirLightEnabled;
            if (dirLightEnabled) {
                glEnable(GL_LIGHT0);
            }
            else {
                glDisable(GL_LIGHT0);
            }
        }
        if (key == '5') {
            spotLightEnabled = !spotLightEnabled;
            if (spotLightEnabled) {
                glEnable(GL_LIGHT2);
            }
            else {
                glDisable(GL_LIGHT2);
            }
        } if (key == '6') {
            pointLightEnabled = !pointLightEnabled;
            if (pointLightEnabled) {
                glEnable(GL_LIGHT1);
            }
            else {
                glDisable(GL_LIGHT1);
            }
        }

        if (cameraMode == PERSPECTIVE) {
            if (key == 'w' && direction != 0) direction = 2;
            if (key == 'd' && direction != 3) direction = 1;
            if (key == 's' && direction != 2) direction = 0;
            if (key == 'a' && direction != 1) direction = 3;
        }
        else if (cameraMode == FIRST_PERSON) {
            if (key == 'a') {
                cameraAngle -= 90.0f;
                direction = (direction + 1) % 4;
            }
            if (key == 'd') {
                cameraAngle += 90.0f;
                direction = (direction + 3) % 4;
            }
        }
        else {
            if (key == 'w' && direction != 2) direction = 0;
            if (key == 'd' && direction != 3) direction = 1;
            if (key == 's' && direction != 0) direction = 2;
            if (key == 'a' && direction != 1) direction = 3;
        }
    }
}


void ofApp::updateLights() {
    // Atualiza a posi��o da luz direcional
    dirLightPosition[0] = dirVec3f.x;
    dirLightPosition[1] = dirVec3f.y;
    dirLightPosition[2] = dirVec3f.z;
    dirLightPosition[3] = 0.0;

    // Luz Direcional
    glLightfv(GL_LIGHT0, GL_POSITION, dirLightPosition);
    glLightfv(GL_LIGHT0, GL_AMBIENT, dirLightAmbientEnabled ? dirLightAmbient : noLight);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, dirLightDiffuseEnabled ? dirLightDiffuse : noLight);
    glLightfv(GL_LIGHT0, GL_SPECULAR, dirLightSpecularEnabled ? dirLightSpecular : noLight);

    // Luz Foco (Spotlight)
    GLfloat spotLightPosition[] = {
        food.x * GRID_SIZE + GRID_SIZE / 2.0f,
        food.y * GRID_SIZE + GRID_SIZE / 2.0f,
        (cameraMode == ORTHO) ? 200.0f : 50.0f,
        1.0f
    };

    GLfloat spotLightDirection[] = {
        0.0f,
        0.0f,
        -1.0f
    };

    glLightfv(GL_LIGHT2, GL_POSITION, spotLightPosition);
    glLightfv(GL_LIGHT2, GL_SPOT_DIRECTION, spotLightDirection);
    glLightfv(GL_LIGHT2, GL_AMBIENT, spotLightAmbientEnabled ? spotLightAmbient : noLight);
    glLightfv(GL_LIGHT2, GL_DIFFUSE, spotLightDiffuseEnabled ? spotLightDiffuse : noLight);
    glLightfv(GL_LIGHT2, GL_SPECULAR, spotLightSpecularEnabled ? spotLightSpecular : noLight);

    glLightf(GL_LIGHT2, GL_SPOT_CUTOFF, (cameraMode == ORTHO) ? 120.0f : 60.0f);
    glLightf(GL_LIGHT2, GL_SPOT_EXPONENT, (cameraMode == ORTHO) ? 2.0f : 10.0f);

    // Luz Pontual
    GLfloat pointLightPosition[] = {
        snake[0].x * GRID_SIZE + GRID_SIZE / 2.0f,
        snake[0].y * GRID_SIZE + GRID_SIZE / 2.0f,
        10.0f,
        1.0f
    };

    glLightfv(GL_LIGHT1, GL_POSITION, pointLightPosition);
    glLightfv(GL_LIGHT1, GL_AMBIENT, pointLightAmbientEnabled ? pointLightAmbient : noLight);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, pointLightDiffuseEnabled ? pointLightDiffuse : noLight);
    glLightfv(GL_LIGHT1, GL_SPECULAR, pointLightSpecularEnabled ? pointLightSpecular : noLight);

    glLightf(GL_LIGHT1, GL_CONSTANT_ATTENUATION, 0.8f);
    glLightf(GL_LIGHT1, GL_LINEAR_ATTENUATION, 0.01f);
    glLightf(GL_LIGHT1, GL_QUADRATIC_ATTENUATION, 0.001f);
}



void ofApp::update() {
    float currentTime = ofGetElapsedTimef();
    if (currentTime - lastUpdateTime >= updateInterval) {
        updateGame();
        lastUpdateTime = currentTime;
    }
    updateLights();

}


void ofApp::updateGame() {
    if (resetting) {
        if (ofGetElapsedTimef() >= resetTimer) {
            gameState = MENU;
        }
        return;
    }

    if (reducing) {
        if (!snake.empty() && reduceIndex < snake.size() - 1) {
            snake.pop_back();
        }
        else {
            resetting = true;
            resetTimer = ofGetElapsedTimef() + 1.0f;
        }
        return;
    }

    Point head = snake.front();

    switch (direction) {
    case 0: head.y -= 1; break;
    case 1: head.x += 1; break;
    case 2: head.y += 1; break;
    case 3: head.x -= 1; break;
    }

    if (head.x < 0 || head.y < 0 || head.x >= GRID_COUNT || head.y >= GRID_COUNT) {
        reducing = true;
        reduceIndex = 0;
        return;
    }

    for (int i = 1; i < snake.size(); ++i) {
        if (snake[i].x == head.x && snake[i].y == head.y) {
            reducing = true;
            reduceIndex = 0;
            return;
        }
    }

    if (head.x == food.x && head.y == food.y) {
        snake.push_front(head);
        spawnFood();
        score += 10;

        if (score > highScore) {
            highScore = score;
            std::ofstream outputFile(highScoreFile);
            if (outputFile.is_open()) {
                outputFile << highScore;
                outputFile.close();
            }
        }
        glowing = true;
        glowFrames = 50;
    }
    else {
        snake.push_front(head);
        snake.pop_back();
    }
}


void ofApp::drawPlatform() {
    float platformSize = GRID_COUNT * GRID_SIZE;
    float platformThickness = GRID_SIZE / 10.0f;
    float platformCenter = GRID_COUNT * GRID_SIZE / 2.0f;
    float wallHeight = GRID_SIZE * 2.0f; // Altura da parede
    float wallThickness = GRID_SIZE / 2.0f; // Espessura da parede


    if (dirLightEnabled) {
        glEnable(GL_LIGHT0);
    }
    else {
        glDisable(GL_LIGHT0);
    }

    ofSetColor(192, 192, 192);
    loadMaterial(1);
    img1.bind();

    glPushMatrix();
    if (cameraMode == ORTHO) {
        float boardX = (ofGetWidth() - platformSize) / 2.0f;
        float boardY = (ofGetHeight() - platformSize) / 2.0f;

        glBegin(GL_QUADS);
        glTexCoord2f(0.0f, 0.0f); glVertex3f(boardX, boardY, 0);
        glTexCoord2f(1.0f, 0.0f); glVertex3f(boardX + platformSize, boardY, 0);
        glTexCoord2f(1.0f, 1.0f); glVertex3f(boardX + platformSize, boardY + platformSize, 0);
        glTexCoord2f(0.0f, 1.0f); glVertex3f(boardX, boardY + platformSize, 0);
        glEnd();
    }
    else {
        glTranslatef(platformCenter, platformCenter, -platformThickness / 2.0f);
        glScalef(platformSize, platformSize, platformThickness);
        cube_unit();
    }
    glPopMatrix();

    img1.unbind();

    if (cameraMode == FIRST_PERSON) {
        loadMaterial(1);
        img4.bind(); // Textura da parede

        float textureWidth = img4.getWidth();
        float textureHeight = img4.getHeight();
        float tileFactorX, tileFactorY;

        // Parede superior (horizontal)
        tileFactorX = platformSize / textureWidth;
        tileFactorY = wallHeight / textureHeight;
        // Aplicar tiling na parede superior
        glMatrixMode(GL_TEXTURE);
        glPushMatrix();
        glScalef(tileFactorX, tileFactorY, 1.0f);
        glRotatef(90, 0.0f, 0.0f, 1.0f);       // Rotacionar textura 90 graus
        glMatrixMode(GL_MODELVIEW); // Voltar para a matriz de modelo

        glPushMatrix();
        glTranslatef(0, platformCenter, wallHeight / 2.0f);
        glScalef(wallThickness, platformSize, wallHeight);
        cube_unit(); // Desenhar o cubo
        glPopMatrix();

        glMatrixMode(GL_TEXTURE);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);

        // Aplicar tiling na parede inferior
        glMatrixMode(GL_TEXTURE);
        glPushMatrix();
        glScalef(tileFactorX, tileFactorY, 1.0f);
        glMatrixMode(GL_MODELVIEW);

        glPushMatrix();
        glTranslatef(platformCenter, 0, wallHeight / 2.0f);
        glScalef(platformSize, wallThickness, wallHeight);
        cube_unit();
        glPopMatrix();

        glMatrixMode(GL_TEXTURE);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);

        tileFactorX = wallHeight / textureWidth;
        tileFactorY = platformSize / textureHeight;
        // Aplicar tiling na parede esquerda
        glMatrixMode(GL_TEXTURE);
        glPushMatrix();
        glScalef(tileFactorX, tileFactorY, 1.0f);
        glRotatef(90, 0.0f, 0.0f, 1.0f);
        glMatrixMode(GL_MODELVIEW);

        glPushMatrix();
        glTranslatef(platformSize, platformCenter, wallHeight / 2.0f);
        glScalef(wallThickness, platformSize, wallHeight);
        cube_unit();
        glPopMatrix();

        glMatrixMode(GL_TEXTURE);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);

        glMatrixMode(GL_TEXTURE);
        glPushMatrix();
        glScalef(tileFactorX, tileFactorY, 1.0f);
        glRotatef(90, 0.0f, 0.0f, 1.0f);
        glMatrixMode(GL_MODELVIEW);

        glPushMatrix();
        glTranslatef(platformCenter, platformSize, wallHeight / 2.0f);
        glScalef(platformSize, wallThickness, wallHeight);
        cube_unit();
        glPopMatrix();

        glMatrixMode(GL_TEXTURE);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);

        img4.unbind();
    }
}


void ofApp::draw() {
    if (gameState == MENU) {
        drawMenu();
        return; 
    }

    if (gameState == PLAYING) {
        ofBackground(51, 51, 51);
        if (cameraMode == ORTHO) {
            ofPushMatrix();
            drawPlatform();
            float center = (ofGetWidth() - GRID_COUNT * GRID_SIZE) / 2.0f;
            float height = (ofGetHeight() - GRID_COUNT * GRID_SIZE) / 2.0f;
            ofPushMatrix();
            ofTranslate(center, height);
            for (int i = 0; i < snake.size(); ++i) {
                drawRectangle(snake[i].x, snake[i].y, 0.0f, 1.0f, 0.0f);
            }
            drawRectangle(food.x, food.y, 1.0f, 0.0f, 0.0f);
            ofPopMatrix();
            ofPopMatrix();
        }
        else {
            camera.begin();

            if (cameraMode == PERSPECTIVE) {
                float center = GRID_COUNT * GRID_SIZE / 2.0f;
                float height = GRID_COUNT * GRID_SIZE * 1.5f;

                camera.setPosition(center, -center * 2, height);
                camera.lookAt(glm::vec3(center, center, 0));
                camera.begin();

                drawPlatform();

                for (int i = 0; i < snake.size(); ++i) {
                    drawRectangle(snake[i].x, snake[i].y, 0.0f, 1.0f, 0.0f);
                }
                drawRectangle(food.x, food.y, 1.0f, 0.0f, 0.0f);

                camera.end();
            }
            else if (cameraMode == FIRST_PERSON) {
                Point head = snake.front();

                float cameraX = head.x * GRID_SIZE + GRID_SIZE / 2.0f;
                float cameraY = head.y * GRID_SIZE + GRID_SIZE / 2.0f;
                float cameraZ = GRID_SIZE;

                glm::vec3 lookAtPosition;
                switch (direction) {
                case 0:
                    lookAtPosition = glm::vec3(cameraX, cameraY - GRID_SIZE, cameraZ);
                    break;
                case 1:
                    lookAtPosition = glm::vec3(cameraX + GRID_SIZE, cameraY, cameraZ);
                    break;
                case 2:
                    lookAtPosition = glm::vec3(cameraX, cameraY + GRID_SIZE, cameraZ);
                    break;
                case 3:
                    lookAtPosition = glm::vec3(cameraX - GRID_SIZE, cameraY, cameraZ);
                    break;
                }

                camera.setPosition(cameraX, cameraY, cameraZ);
                camera.lookAt(lookAtPosition, glm::vec3(0, 0, 1));

                camera.begin();

                drawPlatform();

                for (int i = 0; i < snake.size(); ++i) {
                    drawRectangle(snake[i].x, snake[i].y, 0.0f, 1.0f, 0.0f);
                }

                drawRectangle(food.x, food.y, 1.0f, 0.0f, 0.0f);

                camera.end();
            }

            camera.end();
        }

        if (resetting) {
            ofPushMatrix();
            ofSetColor(255, 0, 0);
            ofDrawBitmapString("Game Over | Score: " + std::to_string(score), ofGetWidth() / static_cast<float>(2) - 80, ofGetHeight() / static_cast<float>(2));
            ofPopMatrix();
        }
        ofPushMatrix();
        glDisable(GL_LIGHTING);
        glDisable(GL_LIGHT0);
        glDisable(GL_LIGHT1);
        glDisable(GL_LIGHT2);

        ofSetColor(255, 255, 255);
        ofDrawBitmapString("High Score: " + std::to_string(highScore), 10, 20);
        ofDrawBitmapString("Score: " + std::to_string(score), 10, 40);

        glEnable(GL_LIGHTING);
        if (dirLightEnabled) glEnable(GL_LIGHT0);
        if (spotLightEnabled) glEnable(GL_LIGHT2);
        if (pointLightEnabled) glEnable(GL_LIGHT1);

        ofPopMatrix();
    }
}


void ofApp::drawMenu() {
    ofPushMatrix();
    glDisable(GL_LIGHTING);
    glDisable(GL_LIGHT0);
    glDisable(GL_LIGHT1);
    glDisable(GL_LIGHT2);

    ofPopMatrix();
    ofBackground(30, 30, 30);
    ofSetColor(255);

    float centerX = ofGetWidth() / 2.0f;
    float centerY = ofGetHeight() / 3.0f;

    ofDrawBitmapString("SNAKE GAME", centerX - 50, centerY);

    float optionY = centerY + 50;
    for (int i = 0; i < menuOptions.size(); ++i) {
        if (i == selectedOption) {
            ofSetColor(0, 255, 0);
            ofDrawBitmapString("-> " + menuOptions[i] + " <-", centerX - 60, optionY);
        }
        else {
            ofSetColor(255);
            ofDrawBitmapString(menuOptions[i], centerX - 40, optionY);
        }
        optionY += 30;
    }

    ofSetColor(150);
    float instructionsY = optionY + 50;
    ofDrawBitmapString("Controles:", centerX - 100, instructionsY);
    ofDrawBitmapString("- W/S: Navegar no menu", centerX - 100, instructionsY + 20);
    ofDrawBitmapString("- Enter: Selecionar opcao", centerX - 100, instructionsY + 40);
    ofDrawBitmapString("- 1/2/3: Alternar modos de camera", centerX - 100, instructionsY + 60);
    ofDrawBitmapString("- 4: Ativar/Desativar Luz Direcional", centerX - 100, instructionsY + 80);
    ofDrawBitmapString("- 5: Ativar/Desativar Luz Foco", centerX - 100, instructionsY + 100);
    ofDrawBitmapString("- 6: Ativar/Desativar Luz Pontual", centerX - 100, instructionsY + 120);
    ofDrawBitmapString("- Esc: Sair do jogo", centerX - 100, instructionsY + 140);

    glEnable(GL_LIGHTING);
    if (dirLightEnabled) glEnable(GL_LIGHT0);
    if (spotLightEnabled) glEnable(GL_LIGHT2);
    if (pointLightEnabled) glEnable(GL_LIGHT1);
}


void ofApp::drawRectangle(int x, int y, float r, float g, float b) {
    float cellSize = GRID_SIZE;

    float xpos = x * cellSize + cellSize / 2.0f;
    float ypos = y * cellSize + cellSize / 2.0f;

    if (food.x == x && food.y == y) {
        loadMaterial(4);
        img3.bind();
    }
    else {
        loadMaterial(5);
        img2.bind();
    }

    ofSetColor(r * 255, g * 255, b * 255);
    
    glPushMatrix();
    glTranslatef(xpos, ypos, 0);
    glScalef(cellSize, cellSize, cellSize);
    cube_unit();
    glPopMatrix();

    if (food.x == x && food.y == y) {
        img3.unbind();
    }
    else {
        img2.unbind();
    }
}


void ofApp::cube_unit() {
    float p = 0.5f;

    glBegin(GL_QUADS);

    glNormal3f(0, 0, 1);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(-p, -p, p);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(p, -p, p);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(p, p, p);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(-p, p, p);

    glNormal3f(0, 0, -1);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(-p, -p, -p);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(p, -p, -p);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(p, p, -p);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(-p, p, -p);

    glNormal3f(1, 0, 0);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(p, -p, -p);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(p, -p, p);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(p, p, p);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(p, p, -p);

    glNormal3f(-1, 0, 0);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(-p, -p, -p);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(-p, -p, p);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(-p, p, p);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(-p, p, -p);

    glNormal3f(0, 1, 0);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(-p, p, -p);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(p, p, -p);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(p, p, p);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(-p, p, p);

    glNormal3f(0, -1, 0);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(-p, -p, -p);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(p, -p, -p);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(p, -p, p);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(-p, -p, p);

    glEnd();
}




