
echo "A terminar todos os componentes Googol (Gateway, Queue, Downloader, Client)..."

# Mata todos os processos Java com a palavra 'search.' (nos teus pacotes)
sudo pkill -f "search."

echo "Todos os processos foram terminados (se existiam)."
