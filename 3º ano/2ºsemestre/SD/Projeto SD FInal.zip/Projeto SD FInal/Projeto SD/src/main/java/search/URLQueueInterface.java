package search;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface URLQueueInterface extends Remote {

    // Método chamado pelo Gateway para adicionar um URL à fila
    void addURL(String url) throws RemoteException;

    // Método chamado pelo Downloader para obter o próximo URL da fila
    String getNextURL() throws RemoteException;
}
